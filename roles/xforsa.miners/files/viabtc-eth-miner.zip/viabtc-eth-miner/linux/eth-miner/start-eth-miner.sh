#!/usr/bin/env sh
./ethminer -U -F http://eth-proxyLANaddress:8080/workID